#include "pch.h"
#include "MonoBehaviour.h"

MonoBehaviour::MonoBehaviour() : Super(ComponentType::Script)
{

}

MonoBehaviour::~MonoBehaviour()
{

}

void MonoBehaviour::Init()
{

}

void MonoBehaviour::Update()
{

}
